package com.example.aaabbbccc;

import static android.app.Notification.EXTRA_NOTIFICATION_ID;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.RemoteException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.altbeacon.beacon.Beacon;
import org.altbeacon.beacon.BeaconConsumer;
import org.altbeacon.beacon.BeaconManager;
import org.altbeacon.beacon.BeaconParser;
import org.altbeacon.beacon.Identifier;
import org.altbeacon.beacon.RangeNotifier;
import org.altbeacon.beacon.Region;
import org.altbeacon.beacon.service.RunningAverageRssiFilter;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.LinkedList;
import java.util.Queue;

// 비콘이 쓰이는 클래스는 BeaconConsumer 인터페이스를 구현
public class MainActivity extends AppCompatActivity implements BeaconConsumer {
    private BeaconManager beaconManager;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    public static Region mregion = new Region("region1",
            Identifier.parse("22222222-2222-2222-2222-222222222222"),null, null);
    // 감지된 비콘들을 임시로 담을 리스트
    String firebaselocation;

    int l;

    NotificationManager manager;
    NotificationCompat.Builder builder;

    private static String CHANNEL_ID = "channel1";
    private static String CHANEL_NAME = "Channel1";

    class difference {
        int location;
        double euclideanDistance;
        int x;
        int y;

        difference() {
            this.location = location;
            this.euclideanDistance= euclideanDistance;
            this.x = x;
            this.y = y;
        }
    }
    class knnDifference {
        int location = 0;
        double diff = 0;

        knnDifference() {
            this.location = location;
            this.diff = diff;
        }
    }


    int n3count=0;
    int n4count=1;
    int made;

    ArrayList<Integer> diffo = new ArrayList<Integer>(Arrays.asList(null,null,null,null));
    ArrayList<Double> smooth = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> firstrssi = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> secondrssi = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> thirdrssi = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> avgrssi = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> num2 = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));
    ArrayList<Double> num3 = new ArrayList<Double>(Arrays.asList(null,null,null,null,null,null,null,null,null));

    double temp = 0;
    int floor;
    difference[] diff = new difference[20];//노드수만/큼
    difference[] diff2 = new difference[20];//노드수만/큼 큐로 대소비교하기위해

    knnDifference[] knndiff= new knnDifference[3];
    double knn3x= 0 ,knn3y=0;
    Queue<Integer> qx = new LinkedList<>();
    Queue<Integer> qy = new LinkedList<>();
    Queue<Integer> qlocation = new LinkedList<>();

    int qcount=0;
    int firstlocation=0;
    int secondlocation=0;
    int firstx=0;
    int secondx=0;
    int firsty=0;
    int secondy=0;

    int n2count=0;
    Queue<Double> qb1 = new LinkedList<>();
    Queue<Double> qb2 = new LinkedList<>();
    Queue<Double> qb3 = new LinkedList<>();
    Queue<Double> qb4 = new LinkedList<>();
    Queue<Double> qb5 = new LinkedList<>();
    Queue<Double> qb6 = new LinkedList<>();
    Queue<Double> qb7 = new LinkedList<>();
    Queue<Double> qb8 = new LinkedList<>();
    Queue<Double> qb9 = new LinkedList<>();
    Double firstrssi1;
    Double firstrssi2;
    Double firstrssi3;
    Double firstrssi4;
    Double firstrssi5;
    Double firstrssi6;
    Double firstrssi7;
    Double firstrssi8;
    Double firstrssi9;
    Double secondrssi1;
    Double secondrssi2;
    Double secondrssi3;
    Double secondrssi4;
    Double secondrssi5;
    Double secondrssi6;
    Double secondrssi7;
    Double secondrssi8;
    Double secondrssi9;

    double[][] DB = {
            {63.36, 61.47, 66.57, 73.88, 80.95, 83.08, 66.33, 82.1, 82.44},
            {65.78, 54.79, 59.37, 80.28, 86.02, 74.86, 80.85, 84, 80.88},
            {72.62, 64, 66.2, 85, 84, 76.16, 88, 90, 66.4},
            {64.35, 68.78, 74.81, 73.1, 77.06, 82.69, 69.27, 82.34, 86.81},
            {65.07, 73.57, 78.72, 67.93, 74.22, 81.01, 69.27, 82.75, 88.68},

            {68.79, 77.91, 81.66, 59.65, 62.01, 77.15, 70.55, 80.97, 85.73},
            {70.86, 81.22, 86.04, 67.03, 66.02, 67.52, 67.81, 78.22, 81.96},
            {65.26, 82.42, 86.48, 68.91, 75.05, 82.75, 64.50, 73.42, 79.18},
            {67.99, 86.89, 87.44, 72, 77.75, 84.96, 62.48, 72.23, 76.75},
            {68.14, 80.81, 83.51, 74.68, 79.60, 87, 51.08, 62.60, 65.43},

            {79.67, 90, 80.28, 83.91, 87, 86.27, 66.98, 61.01, 59.44 },
            {80.38, 81.26, 67.85, 84.88, 81.68, 77.85, 68.09, 66.54, 50.39},
            {84.37, 83.22, 73.86, 86.92, 81.18, 79.39, 76.99, 70.66, 61.60},
            {86.90, 81.95, 64.96, 83.33, 77.35, 70.52, 80.11, 79.91, 70.63},//14
            {87.17, 81.60, 68.90, 71.02, 69.01, 72.73, 83.15, 81.56, 66.66},//15

            {84.35, 80.78, 71.57, 79.32, 69.42 , 51.15 ,88,84.67,  68.42},
            {83.41071429, 74.77192982, 67.04123711, 84.74285714, 78.47619048, 67.48305085, 88, 81.78723404, 73.55555556},
            {78.5652173913043,67.0461538461538,66.4819277108434,86,81.5,69.0947368421053,88,82,71.9387755102041},
            {82.52, 86.33, 82.93, 68.59, 51.20, 62.46, 82.69, 86.27, 80.81},
            {87,87,77.4615384615385,71.5423728813559,67.4464285714286,64.75,86.4444444444444,83.037037037037,78.4318181818182}
    };//비콘 DB
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        TimerTask task = new TimerTask() {

            Uri notification2 = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone ringtone = RingtoneManager.getRingtone(getApplicationContext(), notification2);
            @Override
            public void run() {
                databaseReference.child("state").limitToLast(1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        if (task.isSuccessful()){
                            DataSnapshot snapshot = task.getResult();
                            for (DataSnapshot result : snapshot.getChildren()) {
                                int firescan = result.getValue(Integer.class);
                                if (firescan==0){
                                    if (l==20||l==19||l==18||l==17||l==16) break;
                                    showNoti();
                                    ringtone.play();
                                }
                            }
                        }else {
                            Log.e("firebase", "Error getting data", task.getException());
                        }
                    }
                });
                databaseReference.child("location").limitToLast(1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        if (task.isSuccessful()){
                            DataSnapshot snapshot = task.getResult();
                            for (DataSnapshot result : snapshot.getChildren()) {
                                int locationscan = result.getValue(Integer.class);
                                l = locationscan;

                            }
                        }else {
                            Log.e("firebase", "Error getting data", task.getException());
                        }
                    }
                });
            }
        };
        new Timer().scheduleAtFixedRate(task, 0l, 2500);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 실제로 비콘을 탐지하기 위한 비콘매니저 객체를 초기화
        Button sendbt = (Button) findViewById(R.id.button);
        Button changepage=(Button) findViewById(R.id.button2);
        sendbt.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                TimerTask task = new TimerTask() {
                    @Override//limitToLast(1):FIRE BASE REALTIME DATABASE에서 통신 성공시 값을가져오는데 마지막 1개 값만 가져오겠다는것
                    public void run() {
                        databaseReference.child("location").limitToLast(1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DataSnapshot> task) {
                                if (!task.isSuccessful()) {
                                    Log.e("firebase", "Error getting data", task.getException());
                                }
                                else {
                                    Log.d("firebase", String.valueOf(task.getResult().getValue()));
                                    firebaselocation= String.valueOf(task.getResult().getValue());//가져온 마지막 1개값을 FIREBASELOCATION변수에 저장
                                }
                            }
                        });
                    }
                };
                new Timer().scheduleAtFixedRate(task, 0l, 1000);
            }
        });
        changepage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,mapActivity.class);
                startActivity(intent);
            }
        });
        beaconManager = BeaconManager.getInstanceForApplication(this);
        textView = findViewById(R.id.Textview);
        beaconManager.getBeaconParsers().add(new BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"));
        // 비콘 탐지를 시작한다. 실제로는 서비스를 시작하는것.
        beaconManager.bind(this);
    }

    private void showNoti() {
        builder=null;
        manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            manager.createNotificationChannel(
                    new NotificationChannel(CHANNEL_ID,CHANEL_NAME,NotificationManager.IMPORTANCE_HIGH)
            );
            builder = new NotificationCompat.Builder(this,CHANNEL_ID);
        }else{
            builder=new NotificationCompat.Builder(this);
        }

        Intent intent = new Intent(this, mapActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        Intent fullScreenIntent = new Intent(this, mapActivity.class);
        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(this, 0,
                fullScreenIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent snoozeIntent = new Intent(this,mapActivity.class);
        snoozeIntent.setAction(Intent.ACTION_SCREEN_OFF);
        snoozeIntent.putExtra(EXTRA_NOTIFICATION_ID,0);
        PendingIntent snoozePendingIntent =
                PendingIntent.getBroadcast(this,0,snoozeIntent,0);



        builder.setContentTitle("화재알림");
        builder.setContentText("화재가 발생했습니다");
        builder.setSmallIcon(R.drawable.fire);
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
        builder.setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        builder.setContentIntent(pendingIntent);
        builder.addAction(R.drawable.fire, getString(R.string.app_name),
                snoozePendingIntent);
        builder.setFullScreenIntent(fullScreenPendingIntent, true);
        builder.setAutoCancel(true);

        Notification notification = builder.build();
        manager.notify(1,notification);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        beaconManager.unbind(this);
    }

    @Override
    public void onBeaconServiceConnect() {

        BeaconManager.setRssiFilterImplClass(RunningAverageRssiFilter.class);
        RunningAverageRssiFilter.setSampleExpirationMilliseconds(20000);
        beaconManager.setBackgroundBetweenScanPeriod(0);
        beaconManager.setBackgroundScanPeriod(200);//Background 비콘 스캔주기 0.2초로 지정
        beaconManager.setForegroundBetweenScanPeriod(0);
        beaconManager.setForegroundScanPeriod(200);//Foreground 비콘 스캔주기 0.2초로 지정

        try {
            beaconManager.updateScanPeriods();
        } catch (RemoteException e) {
            e.printStackTrace();
        }


        beaconManager.addRangeNotifier(new RangeNotifier() {


            @Override

            public void didRangeBeaconsInRegion(Collection<Beacon> beacons, Region region) {// 비콘이 감지되면 해당 함수가 호출된다. Collection<Beacon> beacons에는 감지된 비콘의 리스트가,
                // region에는 비콘들에 대응하는 Region 객체가 들어온다.
                ArrayList<Beacon> sortedBeacons;
                ArrayList<Beacon> smoothbeacons;
                ArrayList<Beacon> beaconList = new ArrayList<>();
                double[][] calculatedValue = new double[20][9];//노드수//비콘수
                for(double a[]:calculatedValue){
                    Arrays.fill(a,0);}
                double[] sum = new double[20];//노드수만큼
                Arrays.fill(sum, 0);
                int[] N = new int[20];//노드수만큼
                Arrays.fill(N, 0);
                for(int i=0;i<20;i++){//노드수만큼
                    diff[i]= new difference();
                    diff[i].location=i+1;
                }
                for(int i=0;i<20;i++){//노드수만큼
                    diff2[i]= new difference();
                    diff2[i].location=i+1;
                }
                diff2[0].x = 0; diff2[0].y = 0;
                diff2[1].x = 9; diff2[1].y = 0;
                diff2[2].x = 18; diff2[2].y = 0;
                diff2[3].x = 0; diff2[3].y = 9;
                diff2[4].x = 0; diff2[4].y = 18;
                diff2[5].x = 0; diff2[5].y = 27;
                diff2[6].x = 0; diff2[6].y = 36;
                diff2[7].x = 0; diff2[7].y = 45;
                diff2[8].x = 0; diff2[8].y = 54;
                diff2[9].x = 0; diff2[9].y = 62;
                diff2[10].x = 9; diff2[10].y = 62;
                diff2[11].x = 18; diff2[11].y = 62;
                diff2[12].x = 18; diff2[12].y = 54;
                diff2[13].x = 18; diff2[13].y = 45;
                diff2[14].x = 18; diff2[14].y = 36;
                diff2[15].x = 18; diff2[15].y = 27;
                diff2[16].x = 18; diff2[16].y = 18;
                diff2[17].x = 18; diff2[17].y = 9;
                diff2[18].x = 9; diff2[18].y = 32;
                diff2[19].x=22; diff2[19].y=32;

                diff[0].x = 0; diff[0].y = 0;
                diff[1].x = 9; diff[1].y = 0;
                diff[2].x = 18; diff[2].y = 0;
                diff[3].x = 0; diff[3].y = 9;
                diff[4].x = 0; diff[4].y = 18;
                diff[5].x = 0; diff[5].y = 27;
                diff[6].x = 0; diff[6].y = 36;
                diff[7].x = 0; diff[7].y = 45;
                diff[8].x = 0; diff[8].y = 54;
                diff[9].x = 0; diff[9].y = 62;
                diff[10].x = 9; diff[10].y = 62;
                diff[11].x = 18; diff[11].y = 62;
                diff[12].x = 18; diff[12].y = 54;
                diff[13].x = 18; diff[13].y = 45;
                diff[14].x = 18; diff[14].y = 36;
                diff[15].x = 18; diff[15].y = 27;
                diff[16].x = 18; diff[16].y = 18;
                diff[17].x = 18; diff[17].y = 9;
                diff[18].x = 9; diff[18].y = 32;
                diff[19].x=22; diff[19].y=32;



                if (beacons.size() >2 ) {
                    sortedBeacons = new ArrayList<Beacon>(beacons);
                    Collections.sort(sortedBeacons, new Comparator<Beacon>() {

                        @Override
                        public int compare(Beacon beacon0, Beacon beacon1) {
                            return new Integer(String.valueOf(beacon0.getId3())).compareTo(new Integer(String.valueOf(beacon1.getId3())));
                        }//Sortedbeacon 엔 beacon minor 값을 오름차순으로 정렬
                    });
                    smoothbeacons = new ArrayList<Beacon>(beacons);
                    Collections.sort(smoothbeacons, new Comparator<Beacon>() {

                        @Override
                        public int compare(Beacon beacon0, Beacon beacon1) {
                            return new Integer(String.valueOf(beacon0.getId3())).compareTo(new Integer(String.valueOf(beacon1.getId3())));
                        }//Sortedbeacon 엔 beacon minor 값을 오름차순으로 정렬
                    });
                    for(int n=0; n< smoothbeacons.size(); n++) {//NUM2배열에 비콘 MINOR값 순서대로 [EX)마이너 1은 NUM2배열의 첫번째 값으로] 배열
                        if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(1))) {
                            num2.set(0,((double)smoothbeacons.get(n).getRssi()));
                        } else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(2))) {
                            num2.set(1,((double)smoothbeacons.get(n).getRssi()));
                        }else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(3))) {
                            num2.set(2,((double)smoothbeacons.get(n).getRssi()));
                        }else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(4))) {
                            num2.set(3,((double)smoothbeacons.get(n).getRssi()));
                        }else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(5))) {
                            num2.set(4,((double)smoothbeacons.get(n).getRssi()));
                        }
                        else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(6))) {
                            num2.set(5,((double)smoothbeacons.get(n).getRssi()));
                        }
                        else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(7))) {
                            num2.set(6,((double)smoothbeacons.get(n).getRssi()));
                        }
                        else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(8))) {
                            num2.set(7,((double)smoothbeacons.get(n).getRssi()));
                        }
                        else if (smoothbeacons.get(n).getId3().equals(Identifier.fromInt(9))) {
                            num2.set(8,((double)smoothbeacons.get(n).getRssi()));
                        }

                    }
                    //비콘  RSSI 스무딩

                    qb1.add(num2.get(0));
                    qb2.add(num2.get(1));
                    qb3.add(num2.get(2));
                    qb4.add(num2.get(3));
                    qb5.add(num2.get(4));
                    qb6.add(num2.get(5));
                    qb7.add(num2.get(6));
                    qb8.add(num2.get(7));
                    qb9.add(num2.get(8));
                    n2count++;
                    if(n2count==2){
                        n2count=1;
                        firstrssi1=qb1.peek();
                        qb1.remove();
                        firstrssi2=qb2.peek();
                        qb2.remove();
                        firstrssi3=qb3.peek();
                        qb3.remove();
                        firstrssi4=qb4.peek();
                        qb4.remove();
                        firstrssi5=qb5.peek();
                        qb5.remove();
                        firstrssi6=qb6.peek();
                        qb6.remove();
                        firstrssi7=qb7.peek();
                        qb7.remove();
                        firstrssi8=qb8.peek();
                        qb8.remove();
                        firstrssi9=qb9.peek();
                        qb9.remove();
                        secondrssi1=qb1.peek();

                        secondrssi2=qb2.peek();

                        secondrssi3=qb3.peek();

                        secondrssi4=qb4.peek();

                        secondrssi5=qb5.peek();

                        secondrssi6=qb6.peek();

                        secondrssi7=qb7.peek();

                        secondrssi8=qb8.peek();

                        secondrssi9=qb9.peek();
                        if(firstrssi1!=null&&secondrssi1!=null){
                            smooth.set(0,firstrssi1*0.25+secondrssi1*0.75);
                        }
                        if(firstrssi2!=null&&secondrssi2!=null){
                            smooth.set(1,firstrssi2*0.25+secondrssi2*0.75);
                        }
                        if(firstrssi3!=null&&secondrssi3!=null){
                            smooth.set(2,firstrssi3*0.25+secondrssi3*0.75);
                        }if(firstrssi4!=null&&secondrssi4!=null){
                            smooth.set(3,firstrssi4*0.25+secondrssi4*0.75);
                        }
                        if(firstrssi5!=null&&secondrssi5!=null){
                            smooth.set(4,firstrssi5*0.25+secondrssi5*0.75);
                        }if(firstrssi6!=null&&secondrssi6!=null){
                            smooth.set(5,firstrssi6*0.25+secondrssi6*0.75);
                        }
                        if(firstrssi7!=null&&secondrssi7!=null){
                            smooth.set(6,firstrssi7*0.25+secondrssi7*0.75);
                        }
                        if(firstrssi8!=null&&secondrssi8!=null){
                            smooth.set(7,firstrssi8*0.25+secondrssi8*0.75);
                        }
                        if(firstrssi9!=null&&secondrssi9!=null){
                            smooth.set(8,firstrssi9*0.25+secondrssi9*0.75);
                        }


                        n3count++;
                    }
                    //비콘 RSSI 스무딩 종료



                    //비콘 RSSI 평균값 산출
                    if(n3count==1){
                        for (int i=0; i<9 ;i++){firstrssi.set(i,null);}//비콘수
                        for(int i=0; i<9 ; i++){
                            firstrssi.set(i,smooth.get(i));}

                    }
                    if(n3count==2){
                        for (int i=0; i<9 ;i++){secondrssi.set(i,null);}//비콘수
                        for(int i=0; i<9 ; i++){
                            secondrssi.set(i,smooth.get(i));}

                    }
                    if(n3count==3){
                        for (int i=0; i<9 ;i++){thirdrssi.set(i,null);}//비콘수
                        for(int i=0; i<9 ; i++){
                            thirdrssi.set(i,smooth.get(i));}
                        for(int avgcount=0;avgcount<9;avgcount++)//비콘수
                        { if(firstrssi.get(avgcount)!=null&&secondrssi.get(avgcount)!=null&&thirdrssi.get(avgcount)!=null){
                            avgrssi.set(avgcount,(firstrssi.get(avgcount)+secondrssi.get(avgcount)+thirdrssi.get(avgcount))/3);}
                        else if(firstrssi.get(avgcount) == null || secondrssi.get(avgcount) == null || thirdrssi.get(avgcount) == null)
                        {
                            avgrssi.set(avgcount, null);

                        }


                        }

                        for(int num3copy=0;num3copy<9;num3copy++)
                        { num3.set(num3copy,avgrssi.get(num3copy));}

                        n4count++;
                        //비콘 평균값 산출 종료

                    }
                    if(n3count==4)//카운트가 4일때 마지막 count0으로 초기화
                    {


                        n3count=0;}



                    //유사도 산출 시작
                    for(int j=0; j<20; j++) {//노드수
                        temp=0;
                        for(int i=0; i<9; i++) {//비콘수
                            if (num3.get(i) != null) { //비콘이 인식이 되고, 데이터베이스에 값이 있을 때 연산하겠다는 뜻
                                calculatedValue[j][i] = pow((num3.get(i) + DB[j][i]), 2);
                                N[j] += 1;//감지된 비콘 개수

                            }
                        }
                        for (int k = 0; k < 9; k++) {//비콘수

                            temp = temp + calculatedValue[j][k];
                            sum[j] = sqrt(temp);
                        }

                        diff[j].euclideanDistance = sum[j] / N[j];//유사도
                    }
                    Comparator<difference> comparator = new Comparator<difference>() {
                        @Override
                        public int compare(difference a, difference b) {
                            if (a.euclideanDistance < b.euclideanDistance) {
                                return -1;
                            } else if (a.euclideanDistance > b.euclideanDistance) {
                                return 1;
                            } else {
                                return 0;
                            }
                        }
                    };
                    Arrays.sort(diff, comparator);//유사도로 오름차순

                    //knn시작
                    knn3x=((diff[0].x/diff[0].euclideanDistance+0.000000000000001) + (diff[1].x/diff[1].euclideanDistance+0.000000000000001) + (diff[2].x/diff[2].euclideanDistance+0.000000000000001))
                            /((1/diff[0].euclideanDistance+0.000000000000001)+(1/diff[1].euclideanDistance+0.000000000000001)+(1/diff[2].euclideanDistance+0.000000000000001));
                    knn3y=((diff[0].y/diff[0].euclideanDistance+0.000000000000001) + (diff[1].y/diff[1].euclideanDistance+0.000000000000001) + (diff[2].y/diff[2].euclideanDistance+0.000000000000001))
                            /((1/diff[0].euclideanDistance+0.000000000000001)+(1/diff[1].euclideanDistance+0.000000000000001)+(1/diff[2].euclideanDistance+0.000000000000001));

                    for(int i=0 ; i<3 ; i++){
                        knndiff[i] = new knnDifference();
                    }

                    for(int i=0; i<3 ; i++){
                        knndiff[i].location = diff[i].location;
                        knndiff[i].diff = sqrt(pow((diff[i].x - knn3x),2) + pow((diff[i].y - knn3y),2));
                    }
                    Comparator<knnDifference> knncomparator = new Comparator<knnDifference>() {
                        @Override
                        public int compare(knnDifference a, knnDifference b) {
                            if (a.diff < b.diff) {
                                return -1;
                            } else if (a.diff > b.diff) {
                                return 1;
                            } else {
                                return 0;
                            }
                        }
                    };
                    Arrays.sort(knndiff, knncomparator);

                    beaconList.addAll(beacons);//비콘리스트는 floor 구별하기위해 rssi값을
                    // 오름차순으로정렬한후 내림차순 rssi값이 음수이므로 즉 가장가까운비콘이 첫번째값으로 들어감
                    Collections.sort(beaconList, new Comparator<Beacon>() {

                        @Override
                        public int compare(Beacon beacon0, Beacon beacon1) {
                            return new Integer(String.valueOf(beacon0.getRssi())).compareTo(new Integer(String.valueOf(beacon1.getRssi())));
                        }//beaconlist엔 beacon RSSI값을 오름차순으로 정렬
                    });
                    Collections.reverse(beaconList);//beaconlist값 내림차순
                    floor=new Integer(String.valueOf(beaconList.get(0).getId2()));//beaconlist값 첫번쨰의 메이저값으로 층수구분
                    ///////////////////////////////////////////////////////////////


                    //최빈값 산출 시작
                    if(n4count==5){n4count=1;}
                    diffo.set(n4count-1,diff[0].location);//n4count는 초기값은 1 n3count가 3일때 1씩증가
                    if(diffo.get(0)!=null&&diffo.get(1)!=null&&diffo.get(2)!=null&&diffo.get(3)!=null){
                        int[] data2 = {diffo.get(0), diffo.get(1) ,diffo.get(2),diffo.get(3)};
                        //최빈값이 담길 그릇
                        int[] index2 = new int[21]; //0인덱스의 카운터=노드수 +1
                        int max2 = Integer.MIN_VALUE; //최대값을 저장하기위한 변수 ; 초기값은 정수형의 최소값지정
                        for (int i = 0; i < data2.length; i++) {
                            index2[data2[i]]++; //COUNT
                        }
                        for (int i=0; i< index2.length; i++){
                            if(max2<index2[i]){

                                max2 = index2[i]; //MAX
                                made = i; //최빈값 : MADE
                            }

                        }//최빈값 산출 종료
                        //최종 위치가 튈경우를 대비하여 위치가 좌표기준 1개 노드씩만 이동하게 끔 변경
                        qx.add((int)diff2[made-1].x);
                        qy.add((int)diff2[made-1].y);
                        qlocation.add((int)diff2[made-1].location);

                        qcount++;

                        if(qcount==2){
                            qcount=1;

                            firstx=qx.peek();
                            qx.remove();
                            secondx=qx.peek();
                            firsty=qy.peek();
                            qy.remove();
                            secondy=qy.peek();
                            firstlocation=qlocation.peek();
                            qlocation.remove();
                            secondlocation=qlocation.peek();

                            if((Math.abs(firstx-secondx)>17)||(Math.abs(firsty-secondy)>9)){
                                made=firstlocation;
                                qx.remove();
                                qy.remove();
                                qlocation.remove();
                                qx.add((int)diff2[made-1].x);
                                qy.add((int)diff2[made-1].y);
                                qlocation.add((int)diff2[made-1].location);

                            }
                        }
                    }

                    //KNN산출값에 대해 최빈값 (사용안함)
                    int[] data = {knndiff[2].location,knndiff[1].location,knndiff[0].location,diff[0].location,made};
                    int mode = 0; //최빈값이 담길 그릇
                    int[] index = new int[21]; //인덱스카운터=노드수+1
                    int max = Integer.MIN_VALUE; //최대값을 저장하기위한 변수 ; 초기값은 정수형의 최소값지정
                    for (int i = 0; i < data.length; i++) {
                        index[data[i]]++; //COUNT
                    }
                    for (int i=0; i< index.length; i++){
                        if(max<index[i]){
                            max = index[i]; //MAX
                            mode = i; //최빈값 : MODE
                        }
                    }

                    databaseReference.child("location").push().setValue(made);
                    textView.setText("");
                    textView.append("\nknn3:::" + knndiff[0].location +"단순유사도:::"+diff[0].location);
                    textView.append("\n위치2:::" + knndiff[1].location+"단순유사도:::"+diff[1].location);
                    textView.append("\n위치3:::" + knndiff[2].location+"단순유사도:::"+diff[2].location+"   n3count:::"+n3count);
                    textView.append("\nfirebaselocation:::" + "\n"+firebaselocation);
                    textView.append("\nknnx:::" + "\n"+knn3x);
                    textView.append("\nknny:::" + "\n"+knn3y);
                    textView.append("\n 단순유사도,knn30,1,2,diffo최빈값:::"+mode);
                    textView.append("\n diffo최빈값:::"+made+"   n4count:::"+n4count);
                    textView.append("\n"+diffo.get(0)+" / "+diffo.get(1)+" / "+diffo.get(2)+" / "+diffo.get(3)+" / ");

                    for (int p = 0; p < beaconList.size(); p++) {
                        System.out.println(beaconList.listIterator(p).next().getId3() + " " +beaconList.listIterator(p).next().getRssi());
                        textView.append("\nMINOR:::" + beaconList.listIterator(p).next().getId3());
                        textView.append("\nRSSI:::" + beaconList.listIterator(p).next().getRssi());
                        textView.append("\n:::::::::::::::::::::::::::::::::::::::::");
                    }
                }
            }
        });

        try {
            beaconManager.startRangingBeaconsInRegion(mregion);
        } catch (RemoteException e) {   }

    }

}
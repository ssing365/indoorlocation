package com.example.aaabbbccc;

public class KalmanFilter {
    private static double Q;// process noise(시스템노이즈)
    private static double R;//Measurement noise
    private static double estimatedRSSI;//calculated rssi(추정된 rssi)
    private static double errorCovarianceRSSI;//calculated covariance(오차 공분산 추정값)
    private static boolean isInitialized = false;//initialization flag

    public KalmanFilter() {
        this.Q =0.125;
        this.R = 0.8;
    }
    public KalmanFilter(double Q, double R) {
        this.Q = Q;
        this.R = R;
    }

    public static double applyFilter(double rssi){
        double priorRSSI;
        double K;
        double priorErrorCovarianceRSSI;

        if(!isInitialized){
            priorRSSI = rssi;
            priorErrorCovarianceRSSI = 1;
            isInitialized=true;
        }
        else{
            priorRSSI = estimatedRSSI;
            priorErrorCovarianceRSSI = errorCovarianceRSSI + Q ;
        }
        K = priorErrorCovarianceRSSI / (priorErrorCovarianceRSSI + R);
        estimatedRSSI = priorRSSI + (K * (rssi - priorRSSI));
        errorCovarianceRSSI = (1 - K) * priorErrorCovarianceRSSI;

        return estimatedRSSI;
    }

}